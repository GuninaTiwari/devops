from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()

class NameInput(BaseModel):
    name: str

@app.get("/")
def read_root():
    return {"message": "Hello from FastAPI"}

@app.post("/greet")
def greet(name_input: NameInput):
    return {"message": f"Hello, {name_input.name}! Welcome to the FastAPI and Streamlit project."}

@app.post("/api/message")
async def get_message(name_input: NameInput):
    return {"message": f"Hello, {name_input.name}! Welcome to the FastAPI application."}