import streamlit as st
import requests

st.title("Name Input App")

name = st.text_input("Enter your name:")

if st.button("Submit"):
    if name:
        response = requests.post("http://127.0.0.1:8000/api/message", json={"name": name})

        if response.status_code == 200:
            message = response.json().get("message")
            st.success(message)
        else:
            st.error("Error: Unable to get response from the backend.")
    else:
        st.warning("Please enter a name.")