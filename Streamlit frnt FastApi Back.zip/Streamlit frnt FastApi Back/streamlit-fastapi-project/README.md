# Streamlit-FastAPI Project

This project is a simple web application that combines a Streamlit frontend with a FastAPI backend. The application allows users to input their name and receive a preset message in response.

## Project Structure

```
streamlit-fastapi-project
├── backend
│   ├── app
│   │   ├── main.py          # FastAPI application entry point
│   │   └── __init__.py      # Python package initialization
│   └── requirements.txt      # Backend dependencies
├── frontend
│   ├── app.py               # Streamlit frontend application
│   └── requirements.txt      # Frontend dependencies
├── Dockerfile                # Docker configuration for the project
└── README.md                 # Project documentation
```

## Setup Instructions

### Prerequisites

- Docker installed on your machine.

### Building the Docker Image

1. Navigate to the project directory:
   ```
   cd streamlit-fastapi-project
   ```

2. Build the Docker image:
   ```
   docker build -t streamlit-fastapi-app .
   ```

### Running the Application

1. Run the Docker container:
   ```
   docker run -p 8501:8501 -p 8000:8000 streamlit-fastapi-app
   ```

2. Access the Streamlit frontend in your web browser at:
   ```
   http://localhost:8501
   ```

## Usage

- Input your name in the provided text box on the Streamlit frontend.
- Click the submit button to see the preset message displayed.

## Dependencies

- The backend requires FastAPI and Uvicorn.
- The frontend requires Streamlit.

Refer to the `requirements.txt` files in the `backend` and `frontend` directories for specific versions and additional dependencies.